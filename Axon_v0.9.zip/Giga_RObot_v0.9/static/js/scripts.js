document.addEventListener('DOMContentLoaded', function() {
    const commandLine = document.getElementById('command-line');
    const cpuTempElement = document.getElementById('cpu-temp');
    const enableToggle = document.getElementById('enable-toggle');
    const clearButton = document.getElementById('clear-button');
    let isOn = false;

    // Funkcja wysyłająca komendę do serwera
    function sendCommand(command) {
        commandLine.value += `${command}\n`;
        // Automatyczne przewijanie do dołu
        commandLine.scrollTop = commandLine.scrollHeight;

        fetch('/command', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `command=${command}`,
        });
    }

    // Funkcja aktualizująca temperaturę CPU
    function updateTemperature() {
        fetch('/cpu-temp')
            .then(response => response.json())
            .then(data => {
                cpuTempElement.textContent = data.temp;
            })
            .catch(error => {
                console.error('Error fetching CPU temperature:', error);
                cpuTempElement.textContent = 'N/A';
            });
    }

    // Obsługa przycisków ruchu (z suffixami -down i -up)
    document.querySelectorAll('.control-btn.movement-btn').forEach(button => {
        button.addEventListener('mousedown', function() {
            const command = this.getAttribute('data-command');
            sendCommand(`${command}-down`);
        });

        button.addEventListener('mouseup', function() {
            const command = this.getAttribute('data-command');
            sendCommand(`${command}-up`);
        });
    });

    // Obsługa przycisków makr (bez suffixów)
    document.querySelectorAll('.control-btn:not(.movement-btn)').forEach(button => {
        button.addEventListener('click', function() {
            const command = this.getAttribute('data-command');
            sendCommand(command);
        });
    });

    // Obsługa przycisku Enable Toggle
    enableToggle.addEventListener('click', function() {
        isOn = !isOn;
        const command = isOn ? "on" : "off";

        // Zmiana koloru i tekstu przycisku
        enableToggle.textContent = isOn ? "On" : "Off";
        enableToggle.classList.toggle("btn-success", isOn);
        enableToggle.classList.toggle("btn-danger", !isOn);

        // Wysyłanie komendy do backendu
        sendCommand(`enable-${command}`);
    });

    // Obsługa przycisku Clear
    clearButton.addEventListener('click', function() {
        commandLine.value = ''; // Czyści pole command-line
    });

    // Obsługa aktywnego linku w pasku bocznym
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function() {
            document.querySelector('.nav-link.active')?.classList.remove('active'); // Usuń klasę "active" z poprzedniego
            this.classList.add('active'); // Dodaj klasę "active" do klikniętego
        });
    });

    // Aktualizacja temperatury co 5 sekund
    setInterval(updateTemperature, 5000);

    // Początkowa aktualizacja temperatury
    updateTemperature();
});