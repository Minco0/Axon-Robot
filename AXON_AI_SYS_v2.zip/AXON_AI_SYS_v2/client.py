import os
import requests
import pygame
import speech_recognition as sr
from gtts import gTTS

# -------------------------------------
# KONFIGURACJA
# -------------------------------------
SERVER_URL = 'http://192.168.0.120:5000'  # Adres serwera Flask
ACTIVATION_PHRASE = "Aktywacja modelu"
DEACTIVATION_PHRASE = "Dezaktywacja modelu"

# Flaga do przełączania plików MP3 (aby uniknąć problemów z blokadą pliku)
audio_toggle = True

# Inicjalizacja rozpoznawania mowy i pygame
recognizer = sr.Recognizer()
mic = sr.Microphone()
pygame.mixer.init()


# -------------------------------------
# FUNKCJE TTS/STT
# -------------------------------------
def text_to_speech(text, lang='pl'):
    """
    Zamiana tekstu na mowę przy użyciu gTTS i odtworzenie za pomocą pygame.
    """
    global audio_toggle
    # Przełączamy między response1.mp3 i response2.mp3
    filename = "response1.mp3" if audio_toggle else "response2.mp3"
    
    # Tworzenie pliku MP3
    tts = gTTS(text=text, lang=lang)
    tts.save(filename)
    
    # Odtwarzanie pliku
    pygame.mixer.music.load(filename)
    pygame.mixer.music.play()
    
    # Czekamy, aż zakończy się odtwarzanie
    while pygame.mixer.music.get_busy():
        pass
    
    # Usuwamy poprzedni plik, by nie blokować dostępu
    old_filename = "response2.mp3" if audio_toggle else "response1.mp3"
    if os.path.exists(old_filename):
        try:
            os.remove(old_filename)
        except PermissionError:
            print(f"Nie można usunąć {old_filename}, ponieważ jest w użyciu.")
    
    # Zmieniamy stan flagi
    audio_toggle = not audio_toggle


def recognize_speech_from_mic():
    """
    Rozpoznawanie mowy z mikrofonu przy użyciu SpeechRecognition (Google STT).
    """
    with mic as source:
        print("Słucham...")
        recognizer.adjust_for_ambient_noise(source)  # Kalibracja do szumów otoczenia
        audio = recognizer.listen(source)
        
    try:
        print("Rozpoznawanie mowy...")
        text = recognizer.recognize_google(audio, language="pl-PL")
        return text
    except sr.UnknownValueError:
        print("Nie udało się rozpoznać mowy.")
    except sr.RequestError:
        print("Błąd połączenia z serwisem rozpoznawania mowy.")
    
    return None


# -------------------------------------
# FUNKCJE DO KOMUNIKACJI Z SERWEREM
# -------------------------------------
def send_message(message):
    """
    Wysyła wiadomość do serwera Flask i odtwarza odpowiedź (TTS).
    """
    try:
        response = requests.post(f"{SERVER_URL}/send", json={'message': message})
        response_data = response.json()
        answer = response_data.get('answer', "Brak odpowiedzi z serwera.")
        
        # Wyświetlamy i odtwarzamy odpowiedź
        print(f"Bot: {answer}")
        text_to_speech(answer, lang='pl')

        # Sprawdzenie, czy jest nowy wpis do bazy
        if response_data.get('new_entry'):
            save = input("Czy chcesz dodać tę odpowiedź do bazy danych? (tak/nie): ").strip().lower()
            if save == 'tak':
                save_response(message, answer)

    except requests.exceptions.ConnectionError:
        print("Błąd: Nie można połączyć się z serwerem Flask.")
        text_to_speech("Nie można połączyć się z serwerem Flask.", lang='pl')


def save_response(question, answer):
    """
    Zapisuje nową odpowiedź w bazie danych (za pośrednictwem Flask).
    """
    response = requests.post(f"{SERVER_URL}/save", json={'question': question, 'answer': answer})
    response_data = response.json()
    if response_data.get('status') == 'saved':
        print('Bot: Dziękuję, zapisałem odpowiedź!')
        text_to_speech("Dziękuję, zapisałem odpowiedź!", lang='pl')
    else:
        print('Bot: Wystąpił problem z zapisem odpowiedzi.')
        text_to_speech("Wystąpił problem z zapisem odpowiedzi.", lang='pl')


# -------------------------------------
# LOGIKA AKTYWACJI / DEZAKTYWACJI MODELU
# -------------------------------------
def activate_and_chat():
    """
    Oczekuje na frazę aktywacyjną. Gdy model jest aktywny, przyjmuje pytania głosowe
    i wysyła je do serwera Flask. Można wyłączyć model frazą dezaktywacyjną
    lub wyjść komendą 'koniec/exit/quit'.
    """
    active = False  # Czy model jest aktywny?

    print("Oczekiwanie na frazę aktywacyjną (np. 'Aktywacja modelu')...")

    while True:
        user_input = recognize_speech_from_mic()
        
        if user_input:
            print(f"Ty: {user_input}")
            
            if not active:
                # Sprawdzamy frazę aktywacyjną
                if ACTIVATION_PHRASE.lower() in user_input.lower():
                    active = True
                    print("Bot: Model aktywowany. Słucham Twojego pytania.")
                    text_to_speech("Model aktywowany. Słucham Twojego pytania.", lang='pl')
                else:
                    print("Bot: Czekam na frazę aktywacyjną.")
            else:
                # Sprawdzamy frazę dezaktywacyjną
                if DEACTIVATION_PHRASE.lower() in user_input.lower():
                    active = False
                    print("Bot: Model dezaktywowany.")
                    text_to_speech("Model dezaktywowany.", lang='pl')
                
                # Sprawdzamy czy użytkownik chce zakończyć
                elif user_input.lower() in ["koniec", "exit", "quit"]:
                    print("Bot: Do widzenia!")
                    text_to_speech("Do widzenia!", lang='pl')
                    break
                
                else:
                    # Wyślij zapytanie do serwera
                    send_message(user_input)


# -------------------------------------
# URUCHOMIENIE PROGRAMU
# -------------------------------------
if __name__ == '__main__':
    activate_and_chat()
