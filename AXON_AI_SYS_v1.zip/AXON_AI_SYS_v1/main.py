from flask import Flask, request, jsonify
from langchain_core.prompts import PromptTemplate
from langchain_ollama import OllamaLLM
import json
import os

app = Flask(__name__)

# Tworzymy instancję modelu Ollama
llm = OllamaLLM(model="axon")

# Szablon prompta (template) z poprzednimi pytaniami i odpowiedziami
template = """
Poprzednie pytanie: {previous_question}
Poprzednia odpowiedź: {previous_answer}

Obecne pytanie: {prompt}
"""

# Tworzymy obiekt PromptTemplate, który umożliwia generowanie prompta
prompt_template = PromptTemplate(
    input_variables=["prompt", "previous_question", "previous_answer"],
    template=template
)

knowledge_base_file = 'knowledge_base.json'

# Przechowywanie poprzedniego pytania i odpowiedzi
previous_question = None
previous_answer = None

# Funkcje zarządzające bazą wiedzy
def load_knowledge_base(file_path: str):
    if not os.path.exists(file_path):
        with open(file_path, 'w') as file:
            json.dump({"questions": []}, file)
    
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data

def save_knowledge_base(file_path: str, data: dict):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=2)

def find_best_match(user_question: str, questions: list):
    from difflib import get_close_matches
    matches = get_close_matches(user_question, questions, n=1, cutoff=0.85)
    return matches[0] if matches else None

def get_answer_for_question(question: str, knowledge_base: dict):
    for q in knowledge_base["questions"]:
        if q["question"] == question:
            return q["answer"]
    return None

# Funkcja komunikacji z Ollama
def chat_with_ollama(user_prompt):
    global previous_question, previous_answer

    # Jeśli nie ma poprzedniego pytania i odpowiedzi, ustaw je na "brak"
    if not previous_question or not previous_answer:
        previous_question = "brak"
        previous_answer = "brak"

    # Generujemy prompt na podstawie szablonu
    prompt = prompt_template.format(
        prompt=user_prompt,
        previous_question=previous_question,
        previous_answer=previous_answer
    )
    
    # Wykonujemy zapytanie do LLM
    response = llm.invoke(prompt)
    
    # Zapisujemy bieżące pytanie i odpowiedź do pamięci
    previous_question = user_prompt
    previous_answer = response.strip() if response else "Bot: Wystąpił problem z przetworzeniem odpowiedzi."
    
    return previous_answer

# Przetwarzanie wejścia użytkownika z bazą wiedzy
def process_user_input(user_input):
    knowledge_base = load_knowledge_base(knowledge_base_file)
    best_match = find_best_match(user_input, [q["question"] for q in knowledge_base["questions"]])

    if best_match:
        answer = get_answer_for_question(best_match, knowledge_base)
        return {"answer": answer, "new_entry": False}
    else:
        response = chat_with_ollama(user_input)
        if response:
            return {"answer": response, "new_entry": True}
        else:
            return {"answer": "Bot: Wystąpił problem z przetworzeniem odpowiedzi.", "new_entry": False}

@app.route('/send', methods=['POST'])
def send_message():
    data = request.json
    message = data.get('message')
    
    if message:
        # Przetwarzamy zapytanie użytkownika (z bazą wiedzy i Ollama)
        result = process_user_input(message)
        return jsonify(result)
    
    return jsonify({'status': 'No message received'}), 400

@app.route('/save', methods=['POST'])
def save_message():
    data = request.json
    question = data.get('question')
    answer = data.get('answer')
    
    if question and answer:
        # Zapisujemy nowe pytanie i odpowiedź w bazie wiedzy
        knowledge_base = load_knowledge_base(knowledge_base_file)
        knowledge_base["questions"].append({"question": question, "answer": answer})
        save_knowledge_base(knowledge_base_file, knowledge_base)
        return jsonify({'status': 'saved'})
    
    return jsonify({'status': 'failed'}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
